﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab01
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Lab01_Bai01 f = new Lab01_Bai01();
            f.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Lab01_Bai03 f = new Lab01_Bai03();
            f.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Lab01_Bai05 f = new Lab01_Bai05();
            f.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Lab01_Bai02 f = new Lab01_Bai02();
            f.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Lab01_Bai04 f = new Lab01_Bai04();
            f.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Lab01_Bai06 f = new Lab01_Bai06();
            f.Show();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }
}
