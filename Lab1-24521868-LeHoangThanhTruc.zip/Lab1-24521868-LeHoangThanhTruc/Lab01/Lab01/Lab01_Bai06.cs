﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab01
{
    public partial class Lab01_Bai06 : Form
    {
        public Lab01_Bai06()
        {
            InitializeComponent();
        }

        
        private void txtNhapDSDiem_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnKT_Click(object sender, EventArgs e)
        {
            string input = txtNhapDSDiem.Text;
            bool kiemTra = true;
            string[] parts = input.Split(',');
            for(int i = 0;i < input.Length; i++)
            {
                if (!Char.IsDigit(input[i]) && !Char.IsWhiteSpace(input[i]) && input[i] != ',' && input[i] != '.')
                {
                    kiemTra = false;
                    break;
                }
                
            }
            foreach (string p in parts)
            {
                if (!double.TryParse(p.Trim(), out double result))
                {
                    kiemTra = false;
                    break;
                }
            }
            if (!kiemTra)
            {
                MessageBox.Show("Đã nhập sai format. Thoát chương trình !");
                Close();
            }
            else
            {
                MessageBox.Show("Đã nhập đúng format!");
            }


        }

        private void btnXuat_Click(object sender, EventArgs e)
        {
            string input = txtNhapDSDiem.Text;
            string[] parts = input.Split(',');
            string output = "";

            double sum = 0.0, dtb = 0.0;

            double max = double.Parse(parts[0]);
            double min = double.Parse(parts[0]);

            int demMonDau = 0, demMonRot = 0;

            bool KhongCoMonNaoDuoi6_5 = true;
            bool KhongCoMonNaoDuoi5 = true;
            bool KhongCoMonNaoDuoi3_5 = true;
            bool KhongCoMonNaoDuoi2 = true;

            List<string> dsMon = new List<string>();

            for (int i = 0; i < parts.Length; i++)
            {
                if(double.Parse(parts[i]) >= 5) demMonDau++;
                else demMonRot++;
                if(double.Parse(parts[i]) < 6.5) KhongCoMonNaoDuoi6_5 = false;
                else if(double.Parse(parts[i]) < 5) KhongCoMonNaoDuoi5 = false;
                else if(double.Parse(parts[i]) < 3.5) KhongCoMonNaoDuoi3_5 = false;
                else if(double.Parse(parts[i]) < 2) KhongCoMonNaoDuoi2 = false;
                dsMon.Add("Mon " + (i + 1).ToString());
                parts[i] = parts[i].Trim();
                output = "Mon " + (i + 1).ToString() + ":" + parts[i] + "   ";
                lblDS.Text += output;
                sum +=double.Parse(parts[i]);
                if (i >= 1)
                {
                     if (double.Parse(parts[i]) > max) max = double.Parse(parts[i]);
                     if (double.Parse(parts[i]) < min) min = double.Parse(parts[i]);
                }
            }

            dtb = sum / parts.Length;
            lblDTB.Text = dtb.ToString();

            if (dtb>=8 && KhongCoMonNaoDuoi6_5) lblXepLoai.Text = "Giỏi";
            else if (dtb>=6.5 && KhongCoMonNaoDuoi5) lblXepLoai.Text = "Khá";
            else if (dtb>=5 && KhongCoMonNaoDuoi3_5) lblXepLoai.Text = "Trung bình";
            else if (dtb>=3.5 && KhongCoMonNaoDuoi2) lblXepLoai.Text = "Yếu";
            else lblXepLoai.Text = "Kém";

            for(int i = 0;i < parts.Length; i++)
            {
                if (parts[i] == max.ToString())
                {
                    lblMax.Text = dsMon[i];
                }
                if (parts[i] == min.ToString())
                {
                    lblMin.Text = dsMon[i];
                }
            }
            lblPass.Text = demMonDau.ToString();
            lblFailed.Text = demMonRot.ToString();
        }

        private void lblDS_Click(object sender, EventArgs e)
        {

        }
    }
}
