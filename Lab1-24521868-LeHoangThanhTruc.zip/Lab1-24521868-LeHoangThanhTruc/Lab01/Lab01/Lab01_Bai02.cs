﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab01
{
    public partial class Lab01_Bai02 : Form
    {
        public Lab01_Bai02()
        {
            InitializeComponent();
        }

        

        private void button2_Click(object sender, EventArgs e)
        {
            txt1.Clear();
            txt2.Clear();
            txt3.Clear();
            lblMax.Text = "";
            lblMin.Text = "";
            txt1.Focus();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            double a, b, c;

            bool ok1 = double.TryParse(txt1.Text, out a);
            bool ok2 = double.TryParse(txt2.Text, out b);
            bool ok3 = double.TryParse(txt3.Text, out c);

            if (!ok1 || !ok2 || !ok3)
            {
                MessageBox.Show("Vui lòng nhập số nguyên hợp lệ!", "", MessageBoxButtons.OK, MessageBoxIcon.None);
                return;
            }
            else
            {
                double max = a, min = a;

                if (b > max) max = b;
                if (c > max) max = c;

                if (b < min) min = b;
                if (c < min) min = c;

                lblMax.Text = max.ToString();
                lblMin.Text = min.ToString();
            }
        }
    }
}
