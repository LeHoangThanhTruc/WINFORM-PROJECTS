﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization; 

namespace Lab01
{
    public partial class Lab01_Bai05 : Form
    {
        public Lab01_Bai05()
        {
            InitializeComponent();
        }

        private void Lab01_Bai05_Load(object sender, EventArgs e)
        {

        }

        private void btnTinh_Click(object sender, EventArgs e)
        {
            int a = int.Parse(txtA.Text);
            int b = int.Parse(txtB.Text);
            int giaiThuaA = 1;
            int giaiThuaB = 1;
            int s1 = 0, s2 = 0;
            double s3 = 0;
            string chuoiS1 = "", chuoiS2 = "", chuoiS3 = "";

            if (a == 1) giaiThuaA = 1;
            else if(a > 1)
            {
                for(int i = 1; i <= a; i++)
                {
                    giaiThuaA *= i;
                    s1 += i;
                    chuoiS1 += i.ToString()+ "+";
                }
                chuoiS1 = chuoiS1.Remove(chuoiS1.Length - 1, 1);
            }

            NumberFormatInfo nfi = new NumberFormatInfo
            {
                NumberGroupSeparator = ",",
                NumberDecimalDigits = 0
            };
            
            if (b == 1) giaiThuaB = 1;
            else if(b > 1)
            {
                for (int j = 1; j <= b; j++)
                {
                    giaiThuaB *= j;
                    s2 += j;
                    chuoiS2 += j.ToString() + "+";
                }
                chuoiS2 = chuoiS2.Remove(chuoiS2.Length - 1, 1);
            }

            for(int k = 1; k <= b; k++)
            {
                s3 += Math.Pow(a, k); ;
                chuoiS3 += "A^" + k.ToString() + "+";
            }
            chuoiS3 = chuoiS3.Remove(chuoiS3.Length - 1, 1);

            lblKetQua.ForeColor = Color.Blue;
            lblKetQua.Text = "A! = " + giaiThuaA.ToString("N", nfi) + "                  " + "B! = " + giaiThuaB.ToString("N", nfi) + 
                Environment.NewLine+ Environment.NewLine + "S1 = " + chuoiS1 + "=" + s1.ToString("N", nfi) + 
                Environment.NewLine+ Environment.NewLine + "S2 = " + chuoiS2 + "=" + s2.ToString("N", nfi) +
                Environment.NewLine+ Environment.NewLine + "S3 = " + chuoiS3 + "=" + s3.ToString("N", nfi);
        }
    }
}
