﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab01
{
    public partial class Lab01_Bai04 : Form
    {
        public Lab01_Bai04()
        {
            InitializeComponent();
        }

        private void lblHienThiTyGia_Click(object sender, EventArgs e)
        {

        }

        private void btnChuyenDoi_Click(object sender, EventArgs e)
        {
            double tienVND = double.Parse(txtNhap.Text);
            double tyGiaUSD = 22.775;
            double tyGiaGBP = 31.538;
            double tyGiaSGD = 17.286;
            double tyGiaJPY = 214;
            double tyGiaEUR = 28.132;
            lblHienThiTyGia.Font = new Font(lblHienThiTyGia.Font.Name, lblHienThiTyGia.Font.Size, FontStyle.Italic);

            if (cmbLoaiTienTe.SelectedItem.ToString() == "USD (Đô-la Mỹ)")
            {
                lblHienThiTyGia.Text = "1 USD = 22,775 VND";
                txtDoiTien.Text = (tienVND*tyGiaUSD).ToString();
            }
            else if (cmbLoaiTienTe.SelectedItem.ToString() == "GBP (Bảng Anh)")
            {
                lblHienThiTyGia.Text = "1 GBP = 31, 538 VND";
                txtDoiTien.Text = (tienVND * tyGiaGBP).ToString();
            }
            else if (cmbLoaiTienTe.SelectedItem.ToString() == "SGD (Đô-la Singapore)")
            {
                lblHienThiTyGia.Text = "1 SGD = 17,286 VND";
                txtDoiTien.Text = (tienVND * tyGiaSGD).ToString();
            }
            else if (cmbLoaiTienTe.SelectedItem.ToString()   == "JPY (Yên Nhật)")
            {
                lblHienThiTyGia.Text = "1 JPY = 214 VND";
                txtDoiTien.Text = (tienVND * tyGiaJPY).ToString();
            }
            else if (cmbLoaiTienTe.SelectedItem.ToString() == "EUR (Euro - Châu Âu)")
            {
                lblHienThiTyGia.Text = "1 EUR = 28,132 VND";
                txtDoiTien.Text = (tienVND * tyGiaEUR).ToString();
            }

        }

        private void cmbLoaiTienTe_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void txtDoiTien_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
