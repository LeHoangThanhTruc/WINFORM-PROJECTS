﻿namespace Lab01
{
    partial class Lab01_Bai04
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtNhap = new System.Windows.Forms.TextBox();
            this.btnChuyenDoi = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lblHienThiTyGia = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDoiTien = new System.Windows.Forms.TextBox();
            this.cmbLoaiTienTe = new System.Windows.Forms.ComboBox();
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(60, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Số tiền cần đổi";
            // 
            // txtNhap
            // 
            this.txtNhap.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNhap.Location = new System.Drawing.Point(180, 70);
            this.txtNhap.Name = "txtNhap";
            this.txtNhap.Size = new System.Drawing.Size(189, 24);
            this.txtNhap.TabIndex = 1;
            // 
            // btnChuyenDoi
            // 
            this.btnChuyenDoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChuyenDoi.Location = new System.Drawing.Point(63, 119);
            this.btnChuyenDoi.Name = "btnChuyenDoi";
            this.btnChuyenDoi.Size = new System.Drawing.Size(306, 29);
            this.btnChuyenDoi.TabIndex = 2;
            this.btnChuyenDoi.Text = "Chuyển đổi";
            this.btnChuyenDoi.UseVisualStyleBackColor = true;
            this.btnChuyenDoi.Click += new System.EventHandler(this.btnChuyenDoi_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(60, 229);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "Tỷ giá quy đổi";
            // 
            // lblHienThiTyGia
            // 
            this.lblHienThiTyGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHienThiTyGia.Location = new System.Drawing.Point(177, 223);
            this.lblHienThiTyGia.Name = "lblHienThiTyGia";
            this.lblHienThiTyGia.Size = new System.Drawing.Size(192, 31);
            this.lblHienThiTyGia.TabIndex = 4;
            this.lblHienThiTyGia.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblHienThiTyGia.Click += new System.EventHandler(this.lblHienThiTyGia_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(60, 176);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 18);
            this.label4.TabIndex = 5;
            this.label4.Text = "Số tiền đã đổi";
            // 
            // txtDoiTien
            // 
            this.txtDoiTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDoiTien.Location = new System.Drawing.Point(180, 176);
            this.txtDoiTien.Name = "txtDoiTien";
            this.txtDoiTien.Size = new System.Drawing.Size(189, 24);
            this.txtDoiTien.TabIndex = 6;
            this.txtDoiTien.TextChanged += new System.EventHandler(this.txtDoiTien_TextChanged);
            // 
            // cmbLoaiTienTe
            // 
            this.cmbLoaiTienTe.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLoaiTienTe.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbLoaiTienTe.FormattingEnabled = true;
            this.cmbLoaiTienTe.Items.AddRange(new object[] {
            "USD (Đô-la Mỹ)",
            "EUR (Euro - Châu Âu)",
            "GBP (Bảng Anh)",
            "SGD (Đô-la Singapore)",
            "JPY (Yên Nhật)"});
            this.cmbLoaiTienTe.Location = new System.Drawing.Point(415, 69);
            this.cmbLoaiTienTe.Name = "cmbLoaiTienTe";
            this.cmbLoaiTienTe.Size = new System.Drawing.Size(189, 26);
            this.cmbLoaiTienTe.TabIndex = 7;
            this.cmbLoaiTienTe.SelectedIndexChanged += new System.EventHandler(this.cmbLoaiTienTe_SelectedIndexChanged);
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.AutoSize = true;
            this.lblTieuDe.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTieuDe.Location = new System.Drawing.Point(63, 24);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(181, 24);
            this.lblTieuDe.TabIndex = 8;
            this.lblTieuDe.Text = "Chuyển đổi tiền tệ";
            // 
            // Lab01_Bai04
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 279);
            this.Controls.Add(this.lblTieuDe);
            this.Controls.Add(this.cmbLoaiTienTe);
            this.Controls.Add(this.txtDoiTien);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblHienThiTyGia);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnChuyenDoi);
            this.Controls.Add(this.txtNhap);
            this.Controls.Add(this.label1);
            this.Name = "Lab01_Bai04";
            this.Text = "Lab01_Bai04";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNhap;
        private System.Windows.Forms.Button btnChuyenDoi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblHienThiTyGia;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtDoiTien;
        private System.Windows.Forms.ComboBox cmbLoaiTienTe;
        private System.Windows.Forms.Label lblTieuDe;
    }
}