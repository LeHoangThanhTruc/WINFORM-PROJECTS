﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab01
{
    public partial class Lab01_Bai01 : Form
    {
        public Lab01_Bai01()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int so1, so2;

            bool hopLe1 = int.TryParse(textBox1.Text, out so1);
            bool hopLe2 = int.TryParse(textBox2.Text, out so2);

            if (hopLe1 && hopLe2)
            {
                int tong = so1 + so2;
                textBox3.Text =  tong.ToString();
            }
            else
            {
                MessageBox.Show("Vui lòng nhập số nguyên!","", MessageBoxButtons.OK, MessageBoxIcon.None);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Lab01_Bai01_Load(object sender, EventArgs e)
        {

        }
    }
}
