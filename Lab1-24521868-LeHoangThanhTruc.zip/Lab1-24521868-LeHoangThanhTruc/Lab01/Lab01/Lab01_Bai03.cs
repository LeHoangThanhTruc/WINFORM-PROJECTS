﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab01
{
    public partial class Lab01_Bai03 : Form
    {
        public Lab01_Bai03()
        {
            InitializeComponent();
        }

        private void btnDoc_Click(object sender, EventArgs e)
        {
           switch(txtNhap.Text)
            {
                case "1":
                    lblHienThiKQ.Text = "Một";
                    break;
                case "2":
                    lblHienThiKQ.Text = "Hai";
                    break;
                case "3":
                    lblHienThiKQ.Text = "Ba";
                    break;
                case "4":
                    lblHienThiKQ.Text = "Bốn";
                    break;
                case "5":
                    lblHienThiKQ.Text = "Năm";
                    break;
                case "6":
                    lblHienThiKQ.Text = "Sáu";
                    break;
                case "7":
                    lblHienThiKQ.Text = "Bảy";
                    break;
                case "8":
                    lblHienThiKQ.Text = "Tám";
                    break;
                case "9":
                    lblHienThiKQ.Text = "Chín";
                    break;
                default:
                    MessageBox.Show("Vui lòng nhập số từ 1 đến 9!", "", MessageBoxButtons.OK, MessageBoxIcon.None);
                    break;
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            txtNhap.Clear();
            lblHienThiKQ.Text = "";
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
